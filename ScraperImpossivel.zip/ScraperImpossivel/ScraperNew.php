<?php
# imdb_final.php

require 'vendor/autoload.php';

$client = new \Goutte\Client();

$context = stream_context_create(
    array(
        "http" => array( 
            "header" => "User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36"
        )
    )
);

    $i = $_GET['id'];

$client
    ->request('GET', 'https://licitacoes.tce.ce.gov.br/index.php/licitacao/por_municipios?cd_municipio='.$i)
    ->filter('tbody tr td a')
    ->each(function ($node) use ($client) {
        $infos = $node->html();

        $infos = $client
            ->click($node->link())
            ->filter('.txtCont');
            //->attr('b');
            var_dump('<pre>');
            var_dump($infos);
            var_dump('</pre>');
});